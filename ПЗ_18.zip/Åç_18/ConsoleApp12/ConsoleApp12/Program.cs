﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите требуемую точность: ");
        double precision = Convert.ToDouble(Console.ReadLine());

        double pi = 0.0;
        double previousPi = 0.0;
        int n = 0; 
        do
        {
            previousPi = pi; 
            pi += (n % 2 == 0 ? 1.0 : -1.0) / (2 * n + 1);
            n++;
        } while (Math.Abs(pi * 4 - previousPi * 4) > precision); 
        pi *= 4; 
        Console.WriteLine($"Число π с заданной точностью: {pi}");
        Console.WriteLine($"Количество членов ряда: {n}");
    }
}
