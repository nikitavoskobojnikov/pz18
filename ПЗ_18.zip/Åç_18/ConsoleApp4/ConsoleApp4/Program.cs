﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите число в диапазоне от 0 до 18446744073709551615 (unsigned long): ");
        if (ulong.TryParse(Console.ReadLine(), out ulong number))
        {
            string hexRepresentation = number.ToString("X");
            Console.WriteLine($"Шестнадцатеричное представление числа {number} : {hexRepresentation}");
        }
        else
        {
            Console.WriteLine("Ошибка введено слишком большое число.");
        }
    }
}
