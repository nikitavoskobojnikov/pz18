﻿using System;
class Program
{
    static double Polynomial(double x, double a, double b, double c, double d)
    {
        return a * Math.Pow(x, 3) + b * Math.Pow(x, 2) + c * x + d;
    }
    static double PolynomialDerivative(double x, double a, double b, double c)
    {
        return 3 * a * Math.Pow(x, 2) + 2 * b * x + c;
    }
    static void Main(string[] args)
    {
        Console.Write("Введите коэффициент полинома третьей степени a:");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите коэффициенты полинома третьей степени b:");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите коэффициенты полинома третьей степени c:");
        double c = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите коэффициенты полинома третьей степени d:");
        double d = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите точность :");
        double tolerance = Convert.ToDouble(Console.ReadLine());
        double x0 = 0; 
        double x1;
        int maxIterations = 1000;
        int iteration = 0;
        do
        {
            double fValue = Polynomial(x0, a, b, c, d);
            double fDerivative = PolynomialDerivative(x0, a, b, c);
            if (Math.Abs(fDerivative) < 1e-10)
            {
                Console.WriteLine("Производная слишком мала, метод не может быть применен.");
                return;
            }
            x1 = x0 - fValue / fDerivative;
            iteration++;
            x0 = x1;
        } while (Math.Abs(Polynomial(x1, a, b, c, d)) > tolerance && iteration < maxIterations);
        if (iteration >= maxIterations)
        {
            Console.WriteLine("Метод Ньютона не сошелся за заданное количество итераций.");
        }
        else
        {
            Console.WriteLine($"Найденный корень: {x1}");
        }
    }
}
