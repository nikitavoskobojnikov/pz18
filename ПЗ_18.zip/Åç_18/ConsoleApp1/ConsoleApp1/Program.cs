﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите начало интервала: ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите конец интервала: ");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите шаг изменения аргумента: ");
        double h = Convert.ToDouble(Console.ReadLine());
        double maxY = double.MinValue; 
        double maxX = a; 
        for (double x = a; x <= b; x += h)
        {
            double y = 5 * Math.Cos(3 * x); 
            if (y > maxY)
            {
                maxY = y;
                maxX = x; 
            }
        }
        Console.WriteLine($"Максимальное значение функции y = 5 * cos(3x) на интервале [{a}, {b}]: {maxY}");
        Console.WriteLine($"Соответствующее значение аргумента x: {maxX}");
    }
}
