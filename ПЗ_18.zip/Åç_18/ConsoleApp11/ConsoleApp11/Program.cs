﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите коэффициент a: ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите коэффициент b: ");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите коэффициент c: ");
        double c = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите количество итераций: ");
        int iterations = Convert.ToInt32(Console.ReadLine());
        double x_min = -10.0; 
        double x_max = 10.0;  
        double maxY = a * Math.Pow(x_max, 2) + b * x_max + c;
        int pointsUnderCurve = 0;
        Random random = new Random();
        for (int i = 0; i < iterations; i++)
        {
            double x = random.NextDouble() * (x_max - x_min) + x_min;
            double y = random.NextDouble() * maxY;
            if (y <= (a * Math.Pow(x, 2) + b * x + c))
            {
                pointsUnderCurve++;
            }
        }
        double area = (double)pointsUnderCurve / iterations * (x_max - x_min) * maxY;
        Console.WriteLine($"Приближенная площадь фигуры, ограниченной параболой и осью абсцисс: {area}");
    }
}
